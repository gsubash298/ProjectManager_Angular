import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {Task} from '../task';
import {Project} from '../project';
import {TaskService} from '../shared_service/task.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router } from "@angular/router";

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.scss']
})
export class ViewTaskComponent implements OnInit {
  private task:Task;
  private tasks:Task[];
  private show:boolean=false;
  private i:number;
  private projectList:Project[];
  private closeResult: string;
  private startDateSort: string;
  private endDateSort: string;
  private prioritySort: number;
  private completedSort: string;
  private updateBtn: string;

  constructor(private taskService: TaskService, private modalService: NgbModal, private router: Router) { }

  ngOnInit() {
    this.task = new Task();
    this.getProjectList();    
  }

  getTaskList() {
    this.taskService.getTaskList(this.task.projectId).subscribe((res : Task[])=>{
      console.log(res);
      this.tasks = res;
      console.log("list of tasks" + this.tasks);
    });
  }
  
  deleteTask(task,i) {
    task.status = 'complete';
    //this.taskService.deleteTask(task.taskId).subscribe((task)=>{
      //console.log(task);
    //})
    this.taskService.updateTask(task).subscribe((task)=>{
      console.log(task);
    })
    var editId = 'edit'+i;  
    (<HTMLInputElement> document.getElementById(i)).disabled = true;
    (<HTMLInputElement> document.getElementById(editId)).disabled = true; 
  }

  editTask(task) {
    //this.show=true;
    this.task=task;
    this.updateBtn="Update";
    this.taskService.storeDataForUpdate(this.task, this.updateBtn);
    this.router.navigate(['/add-task']).then( (e) => {
      if (e) {
        console.log("Navigation is successful!");
      } else {
        console.log("Navigation has failed!");
      }
    });
  }
  updateTask(task:Task) {
    this.task.status = 'open';
    this.taskService.updateTask(this.task).subscribe((task)=>{
      console.log(task);
    })
    this.getTaskList();
  }

  enableDisable(task:Task){
    if (this.task.taskId ==  task.taskId)
      return true;
    else
      return false;
  }

  getProjectList() {
    this.taskService.getProjectList().subscribe((res : Project[])=>{
      console.log(res);
      this.projectList = res;
      console.log("list of projects" + this.projectList);
    });
  }

  open(content) {        
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = result;
      console.log(this.closeResult);
      var splitCloseResult = this.closeResult.split("$$", 3);
      if(splitCloseResult[0] == '--project--') {
        this.task.project = splitCloseResult[1];
        this.task.projectId = +splitCloseResult[2];
        console.log(this.task.project);
        console.log(this.task.projectId);
      }
      this.getTaskList();
    }, (reason) => {      
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  startDateSorting(){
    this.startDateSort = "startDateSort";
    this.endDateSort = "";
    this.prioritySort = null;
    this.completedSort = "";
  }

  endDateSorting(){
    this.startDateSort = "";
    this.endDateSort = "endDateSort";
    this.prioritySort = null;
    this.completedSort = "";
  }

  prioritySorting(){
    this.startDateSort = "";
    this.endDateSort = "";
    this.prioritySort = 0;
    this.completedSort = "";
  }

  completedSorting(){
    this.startDateSort = "";
    this.endDateSort = "";
    this.prioritySort = null;
    this.completedSort = "completedSort";
  }

  disableBtn(task){
    return task.status=="complete";
  }
}
