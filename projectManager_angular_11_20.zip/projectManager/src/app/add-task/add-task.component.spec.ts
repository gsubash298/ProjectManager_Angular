import { async, inject, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { AddTaskComponent } from './add-task.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('AddTaskComponent', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, HttpClientTestingModule],
      declarations: [ AddTaskComponent ],
    })
    .compileComponents();
  }));

  it('should create add task', async(() => {
    const fixture = TestBed.createComponent(AddTaskComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
