export class Project {

    projectId: number;
    project: string;
    projectStartDate: string;
    projectEndDate: string;
    projectPriority: number;
    userId: number;
    employeeId: number;
    noOfTask: number;
    noOfTaskCompleted: number;

}
