import { Component, OnInit } from '@angular/core';
import {User} from '../user';
import {TaskService} from '../shared_service/task.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  private user: User;
  private isCreated:boolean=false;
  private userExist:boolean=false;
  private userError:User;
  private errorMessage:String;
  private userList: User[];
  private addOrUpdateBtn: string;
  private show: boolean=false;
  private firstNameSort:string;
  private lastNameSort:string;
  private employeeIdSort:number;
  private empIdSearch:number;

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    this.addOrUpdateBtn = "Add";
    this.user = new User();
    this.getUserList();
  }

  addOrUpdateUser() {
    if(this.addOrUpdateBtn == "Add") {
      this.addUser();
    } else {
      this.updateUser(this.user);
    }     
  }

  addUser(){
    this.taskService.addUser(this.user).subscribe(user=>{
      console.log(user);
      this.isCreated=true;
      this.userExist=false;
      this.getUserList();
    },
  error=>{
    this.userError=error.error;
    this.isCreated=false;
    this.errorMessage=error.error.description;
    if(error.error.code==409){
      this.isCreated=false;
      this.userExist=true;
    }
    console.log(error);
  })
  }

  getUserList() {
    this.taskService.getUserList().subscribe((res : User[])=>{
      console.log(res);
      this.userList = res;
      console.log("list of tasks" + this.userList);
      this.show=true;
      console.log(this.show);
    });
  }

  editUser(user) {
    this.user=user;
    this.addOrUpdateBtn = "Update";
  }

  updateUser(user:User) {
    this.taskService.updateUser(this.user).subscribe((user)=>{
      console.log(user);
      this.resetForm();
      this.getUserList();
    })
  }

  deleteUser(user) {
    this.taskService.deleteUser(user.userId).subscribe((user)=>{
      console.log(user);
      this.resetForm();
      this.getUserList();
    })    
  }

  resetForm(){
    this.user.firstName='';
    this.user.lastName='';
    this.user.employeeId=null;
  }

  firstNameSorting(){
    this.empIdSearch=null;
    this.firstNameSort="firstNameSort";
    this.lastNameSort="";
    this.employeeIdSort=null;
  }

  lastNameSorting(){
    this.empIdSearch=null;
    this.firstNameSort="";
    this.lastNameSort="lastNameSort";
    this.employeeIdSort=null;
  }

  employeeIdSorting(){
    this.empIdSearch=null;
    this.firstNameSort="";
    this.lastNameSort="";
    this.employeeIdSort=0;    
  }
}
