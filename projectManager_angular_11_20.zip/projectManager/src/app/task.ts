export class Task {

    taskId: number;
    task: string;
    parentId: number;
    parentTask: string;
    priority: number;
    startDate: string;
    endDate: string;
    projectId: number;
    project: string;
    userId: number;
    employeeId: number;
    status: string;   
}
