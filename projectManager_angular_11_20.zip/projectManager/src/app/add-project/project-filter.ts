import {Pipe, PipeTransform } from '@angular/core';
import { Project } from '../project';
@Pipe({
    name: 'projectSortSearchFilter' 
})
export class projectFilter implements PipeTransform {  
    transform(projectList: Project[], projectSearch: string, startDateSort: string, endDateSort: string, prioritySort: number, completedSort: number){        
        console.log("inside the filter");
        console.log(projectSearch);
        if (projectSearch !="" && projectList && projectList.length){
        console.log("inside search logic");
        return projectList.filter(project =>{
            if (projectSearch && project.project.toLowerCase().indexOf(projectSearch.toLowerCase()) === -1){
                return false;
            }
            return true;
        })
        }

        console.log("startDateSort--"+startDateSort); 
        if(startDateSort != "" && startDateSort=="startDateSort") {
            console.log(startDateSort);
            return projectList.sort((a, b) => new Date(a.projectStartDate).toDateString().localeCompare(new Date(b.projectStartDate).toDateString()));
        }

        if(endDateSort != "" && endDateSort=="endDateSort") {
            console.log(endDateSort);
            return projectList.sort((a, b) => new Date(a.projectEndDate).toDateString().localeCompare(new Date(b.projectEndDate).toDateString()));
        }

        if(prioritySort != null) {
            console.log(prioritySort);
            return projectList.sort((a, b) => {
                if (a.projectPriority > b.projectPriority) {
                    return 1;
                }                
                if (a.projectPriority < b.projectPriority) {
                    return -1;
                }
                return 0;
            });
        }
        console.log("completedSort--"+completedSort); 
        if(completedSort != null) {            
            console.log(completedSort);
            return projectList.sort((a,b) => {
                if (a.noOfTaskCompleted > b.noOfTaskCompleted) {
                    return 1;
                }                
                if (a.noOfTaskCompleted < b.noOfTaskCompleted) {
                    return -1;
                }
                return 0;
            });
        }

        else{
            return projectList;
        } 
    }
}
