export class ParentTask {
    parentId: number;
    parentTask: string;
}
