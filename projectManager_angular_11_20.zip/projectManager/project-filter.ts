import {Pipe, PipeTransform } from '@angular/core';
import { Project } from '../project';
@Pipe({
    name: 'projectSearchSortFilter' 
})
export class projectFilter implements PipeTransform {  
    transform(projectList: Project[], projectSearch: String, startDateSort: string, endDateSort: string, prioritySort: number, completedSort: string){
        //if (empIdSearch !=null && projectList && projectList.length){
        //return projectList.filter(user =>{
            //if (empIdSearch && user.employeeId.toString().indexOf(empIdSearch.toString()) === -1){
               // return false;
            //}
            //return true;
        //})
        //}
              
        //if(firstNameSort != "" && firstNameSort=="firstNameSort") {
        //console.log(firstNameSort);
        //return projectList.sort((a, b) => a.firstName.localeCompare(b.firstName));
        //}

        //if(lastNameSort != "" && lastNameSort=="lastNameSort") {
          //  console.log(lastNameSort);
            //return projectList.sort((a, b) => a.lastName.localeCompare(b.lastName));
        //}

        //if(employeeIdSort != null) {
         //   console.log(employeeIdSort);
            //return projectList.sort((a, b) => a.employeeId.toString().localeCompare(b.employeeId.toString()));
        //}
        
        //else{
            return projectList;
        //}
    }
}
